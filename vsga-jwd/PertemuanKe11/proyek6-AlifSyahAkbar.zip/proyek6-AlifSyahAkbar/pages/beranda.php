<div style="height: 500px;">
    <div id="content">
        <div id="beranda-judul">
            <h3>SELAMAT DATANG DI SISTEM INFORMASI PERPUSTAKAAN</h3>
        </div>
        <div id="beranda-konten">
            <h4> "MEMBACA ADALAH JENDELA DUNIA" </h4>
        </div>
    </div>
</div>